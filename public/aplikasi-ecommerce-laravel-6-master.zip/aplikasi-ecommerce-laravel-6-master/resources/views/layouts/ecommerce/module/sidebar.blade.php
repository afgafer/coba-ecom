<div class="card" style="background-color: #bdc3c7">
    <div class="card-body">
        <h3>Main Menu</h3>
        <ul class="menu-sidebar-area">
            <li class="icon-dashboard"><a href="{{ route('customer.dashboard') }}">Dashboard</a></li>
            <li class="icon-customers"><a href="{{ route('customer.orders') }}">Pesanan</a></li>
            <li class="icon-customers"><a href="{{ route('customer.affiliate') }}">Afiliasi</a></li>
            <li class="icon-users"><a href="{{ route('customer.settingForm') }}">Pengaturan</a></li>
        </ul>
    </div>
</div>